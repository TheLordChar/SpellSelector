public interface Filter {
    boolean satisfies(String id);
}
